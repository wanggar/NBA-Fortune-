//
//  cell.swift
//  StocketMarket
//
//  Created by labuser on 11/14/18.
//

import Foundation
import UIKit


class theCell:UICollectionViewCell{

    @IBOutlet weak var playerImage: UIImageView!
    
    @IBOutlet weak var playerPrice: UILabel!
    
}
