//
//  ViewController.swift
//  StocketMarket
//
//  Created by labuser on 11/14/18.
//

import UIKit
import WebKit


var nbaImage:UIImage!
var nbaPrice: String!


class ViewController: UIViewController, UICollectionViewDataSource,UICollectionViewDelegate, UITableViewDelegate,UITableViewDataSource{
    
    
    @IBOutlet weak var newsTableView: UITableView!
    
    
    @IBOutlet weak var playerCollectionView: UICollectionView!

    
    
    @IBAction func searchButton(_ sender: Any) {
       // playerSearcher.isHidden = false
        
    }
    
    var playerImages:[UIImage] = [#imageLiteral(resourceName: "kyrie"),#imageLiteral(resourceName: "james"),#imageLiteral(resourceName: "kd")] //placeholder data
    var playerPrice:[String] = ["$10.54","$14.55","$12.12"]  //placeholder data

    
    private var rssItems: [RSSItem]?
    
    var nbalink:String!
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        view.backgroundColor = UIColor.init(red: 23/255, green: 64/255, blue: 139/255, alpha: 1.0)
        
        playerCollectionView.delegate = self
        playerCollectionView.dataSource = self
        playerCollectionView.reloadData()
        
        
        newsTableView.estimatedRowHeight = 155.0;
        newsTableView.rowHeight = UITableViewAutomaticDimension
        newsTableView.dataSource = self
        newsTableView.delegate = self
        
        fetchData()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    private func fetchData(){
        let feedParser = FeedParser()
        
        
        feedParser.parseFeed(url: "https://www.nba.com/rss/nba_rss.xml") { (rssItems) in
            self.rssItems = rssItems
            OperationQueue.main.addOperation {
                self.newsTableView.reloadSections(IndexSet(integer:0), with: .left)
                
            }
        }
        
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mycell", for: indexPath) as! theCell
        cell.playerImage.image = playerImages[indexPath.row]
        cell.playerPrice.text = playerPrice[indexPath.row]
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
         let playerPage = playerViewController()
         performSegue(withIdentifier: "toNBAPlayer", sender: self)
         nbaImage = playerImages[indexPath.row]
         nbaPrice = playerPrice[indexPath.row]
         print(nbaImage)
         print(nbaPrice)
//         playerPage.playerActionShot.image = nbaImage
//         playerPage.playerPrice.text = nbaPrice
         playerPage.reloadInputViews()
        
    }

    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        guard let rssItems = rssItems else {
            return 0
        }
        return rssItems.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let rssArticle = self.rssItems![indexPath.row]
         let newsPost = newsDetailedViewController()
         nbalink = rssArticle.link
         performSegue(withIdentifier: "toNBANews", sender: self)
         newsPost.feedLink = nbalink
         newsPost.reloadInputViews()
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is newsDetailedViewController{
            let vc = segue.destination as? newsDetailedViewController
            vc?.feedLink = nbalink
        }
       
    } //this is where we get the data
    
    

    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath) as! newsCell
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        if let item = rssItems?[indexPath.item]{
            cell.item = item
        }
        
        return cell
    }
    
    


}

